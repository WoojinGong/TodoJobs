from django.shortcuts import render
from django.shortcuts import HttpResponseRedirect
from todo_main.models import todo
from django.urls import reverse

def index(request):
    _todos = todo.objects.all()
    return render(request, 'index.html', {'todos': _todos})

def create_todo(request):
    content = request.POST['todoContent']
    new_todo = todo(Title=content)
    new_todo.save()
    return HttpResponseRedirect(reverse('index'))

def delete_todo(request):
    _id = request.GET['todoNum']
    to_do = todo.objects.get(id=_id)
    to_do.delete()
    return HttpResponseRedirect(reverse('index'))
